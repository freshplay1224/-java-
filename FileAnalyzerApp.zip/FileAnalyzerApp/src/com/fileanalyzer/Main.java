package com.fileanalyzer;

import com.fileanalyzer.cli.CommandLineApp;

public class Main {
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  УМНЫЙ АНАЛИЗАТОР ФАЙЛОВ");
        System.out.println("  Определение формата по содержимому");
        System.out.println("========================================");

        try {
            CommandLineApp app = new CommandLineApp();
            app.run();
        } catch (Exception e) {
            System.err.println("Критическая ошибка: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\nПрограмма завершена.");
    }
}