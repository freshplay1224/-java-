package com.fileanalyzer.model;

public class FileSignature {
    private String extension;
    private String mimeType;
    private String description;
    private String hexSignature;
    private int offset;
    private int priority; // Приоритет (чем выше, тем важнее)

    public FileSignature(String extension, String mimeType,
                         String description, String hexSignature, int offset) {
        this(extension, mimeType, description, hexSignature, offset, 1);
    }

    public FileSignature(String extension, String mimeType,
                         String description, String hexSignature, int offset, int priority) {
        this.extension = extension;
        this.mimeType = mimeType;
        this.description = description;
        this.hexSignature = hexSignature.toUpperCase().replace(" ", "");
        this.offset = offset;
        this.priority = priority;
    }

    // Геттеры
    public String getExtension() { return extension; }
    public String getMimeType() { return mimeType; }
    public String getDescription() { return description; }
    public String getHexSignature() { return hexSignature; }
    public int getOffset() { return offset; }
    public int getPriority() { return priority; }

    public boolean isArchive() {
        return extension.equals("zip") || extension.equals("rar") ||
                extension.equals("7z") || extension.equals("gz") ||
                extension.equals("tar") || extension.equals("bz2");
    }

    @Override
    public String toString() {
        return extension.toUpperCase() + " - " + description +
                (priority > 1 ? " [приоритет: " + priority + "]" : "");
    }
}