package com.fileanalyzer.model;

public class AnalysisResult {
    private String filePath;
    private String fileName;
    private long fileSize;
    private String currentExtension;
    private String detectedExtension;
    private String mimeType;
    private String description;
    private boolean signatureMatch;
    private boolean extensionMatch;
    private String error;
    private String originalFormat; // Исходный формат для архивов
    private double confidence; // Уверенность в определении (0-1)

    public AnalysisResult() {
        this.signatureMatch = false;
        this.extensionMatch = false;
        this.confidence = 0.0;
    }

    // Геттеры и сеттеры
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }

    public String getCurrentExtension() { return currentExtension; }
    public void setCurrentExtension(String currentExtension) {
        this.currentExtension = currentExtension;
    }

    public String getDetectedExtension() { return detectedExtension; }
    public void setDetectedExtension(String detectedExtension) {
        this.detectedExtension = detectedExtension;
    }

    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isSignatureMatch() { return signatureMatch; }
    public void setSignatureMatch(boolean signatureMatch) {
        this.signatureMatch = signatureMatch;
    }

    public boolean isExtensionMatch() { return extensionMatch; }
    public void setExtensionMatch(boolean extensionMatch) {
        this.extensionMatch = extensionMatch;
    }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }

    public String getOriginalFormat() { return originalFormat; }
    public void setOriginalFormat(String originalFormat) {
        this.originalFormat = originalFormat;
    }

    public double getConfidence() { return confidence; }
    public void setConfidence(double confidence) {
        this.confidence = Math.max(0.0, Math.min(1.0, confidence));
    }

    @Override
    public String toString() {
        if (error != null) {
            return "Ошибка: " + error;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Файл: ").append(fileName).append("\n");
        sb.append("Размер: ").append(fileSize).append(" байт\n");
        sb.append("Текущее расширение: ").append(currentExtension.isEmpty() ? "(нет)" : currentExtension).append("\n");
        sb.append("Определённый формат: ").append(detectedExtension).append("\n");

        if (originalFormat != null && !originalFormat.isEmpty()) {
            sb.append("Исходный формат в архиве: ").append(originalFormat).append("\n");
        }

        sb.append("Описание: ").append(description).append("\n");
        sb.append("MIME-тип: ").append(mimeType).append("\n");
        sb.append("Уверенность: ").append(String.format("%.0f%%", confidence * 100)).append("\n");
        sb.append("Сигнатура найдена: ").append(signatureMatch ? "ДА" : "НЕТ").append("\n");
        sb.append("Расширение корректно: ").append(extensionMatch ? "ДА" : "НЕТ");

        return sb.toString();
    }
}