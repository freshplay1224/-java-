package com.fileanalyzer.util;

import java.nio.charset.StandardCharsets;

public class HexUtils {

    public static byte[] hexStringToByteArray(String hexString) {
        if (hexString == null || hexString.isEmpty()) {
            return new byte[0];
        }

        String cleanHex = hexString.toUpperCase().replace(" ", "").replace("\n", "");
        int len = cleanHex.length();

        // Проверка на четность
        if (len % 2 != 0) {
            throw new IllegalArgumentException("HEX строка должна иметь четную длину");
        }

        byte[] data = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            int high = Character.digit(cleanHex.charAt(i), 16);
            int low = Character.digit(cleanHex.charAt(i + 1), 16);

            if (high == -1 || low == -1) {
                throw new IllegalArgumentException("Некорректный HEX символ");
            }

            data[i / 2] = (byte) ((high << 4) + low);
        }

        return data;
    }

    public static String bytesToHex(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return "";
        }

        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) {
            hex.append(String.format("%02X", b & 0xFF));
        }
        return hex.toString();
    }

    public static String bytesToHex(byte[] bytes, int limit) {
        if (bytes == null || bytes.length == 0) {
            return "";
        }

        int actualLimit = Math.min(bytes.length, limit);
        StringBuilder hex = new StringBuilder();
        for (int i = 0; i < actualLimit; i++) {
            hex.append(String.format("%02X", bytes[i] & 0xFF));
        }
        return hex.toString();
    }

    public static boolean compareBytes(byte[] fileBytes, byte[] signatureBytes, int offset) {
        if (fileBytes.length < offset + signatureBytes.length) {
            return false;
        }

        for (int i = 0; i < signatureBytes.length; i++) {
            if (fileBytes[offset + i] != signatureBytes[i]) {
                return false;
            }
        }

        return true;
    }

    public static boolean isBinaryFile(byte[] bytes) {
        if (bytes.length == 0) return false;

        int textChars = 0;
        int totalChars = Math.min(bytes.length, 1000);

        for (int i = 0; i < totalChars; i++) {
            byte b = bytes[i];
            // Текстовые символы: печатные ASCII, табуляция, новая строка
            if ((b >= 32 && b <= 126) || b == 9 || b == 10 || b == 13) {
                textChars++;
            }
        }

        // Если менее 90% текстовых символов - бинарный файл
        return (double) textChars / totalChars < 0.9;
    }
}