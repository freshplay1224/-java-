package com.fileanalyzer.core;

import com.fileanalyzer.model.FileSignature;
import com.fileanalyzer.util.HexUtils;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class SignatureDatabase {
    private final List<FileSignature> signatures;
    private final Map<String, String> extensionToMime;
    private static final int MAX_READ_SIZE = 8192;

    public SignatureDatabase() {
        signatures = new ArrayList<>();
        extensionToMime = new HashMap<>();
        initializeSignatures();
    }

    private void initializeSignatures() {
        System.out.println("Инициализация умной базы сигнатур файлов...");

        // === ВЫСОКИЙ ПРИОРИТЕТ (3) ===
        addImageSignatures();
        addExecutableSignatures();
        addArchiveSignatures();
        addDocumentSignatures();

        // === СРЕДНИЙ ПРИОРИТЕТ (2) ===
        addAudioVideoSignatures();

        // === НИЗКИЙ ПРИОРИТЕТ (1) ===
        addTextSignatures();
        addMiscellaneousSignatures();

        System.out.println("✅ Загружено " + signatures.size() + " сигнатур файлов");
        System.out.println(getStatistics());
    }

    private void addImageSignatures() {
        // PNG - самый надежный
        addSignature("png", "image/png", "PNG изображение", "89504E470D0A1A0A", 0, 5);

        // JPEG - несколько вариантов
        addSignature("jpg", "image/jpeg", "JPEG изображение", "FFD8FF", 0, 4);
        addSignature("jpg", "image/jpeg", "JPEG с Exif", "FFD8FFE1", 0, 4);

        // GIF
        addSignature("gif", "image/gif", "GIF анимация", "47494638", 0, 4);

        // BMP
        addSignature("bmp", "image/bmp", "Bitmap изображение", "424D", 0, 3);

        // WebP
        addSignature("webp", "image/webp", "WebP изображение", "52494646", 0, 4);

        // ICO
        addSignature("ico", "image/x-icon", "Иконка Windows", "00000100", 0, 4);
    }

    private void addDocumentSignatures() {
        // PDF - очень надежный
        addSignature("pdf", "application/pdf", "PDF документ", "25504446", 0, 5);

        // Старые Office документы
        addSignature("doc", "application/msword", "Документ Word", "D0CF11E0A1B11AE1", 0, 4);
        addSignature("xls", "application/vnd.ms-excel", "Таблица Excel", "D0CF11E0A1B11AE1", 0, 4);

        // Новые Office (ZIP-based) - приоритет ниже
        addSignature("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "Документ Word (2007+)", "504B0304", 0, 2);
        addSignature("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "Таблица Excel (2007+)", "504B0304", 0, 2);

        // RTF
        addSignature("rtf", "application/rtf", "Rich Text Format", "7B5C727466", 0, 3);
    }

    private void addArchiveSignatures() {
        // ZIP - несколько вариантов
        addSignature("zip", "application/zip", "ZIP архив", "504B0304", 0, 4);
        addSignature("zip", "application/zip", "Пустой ZIP архив", "504B0506", 0, 4);

        // RAR
        addSignature("rar", "application/x-rar-compressed", "RAR архив v4", "526172211A0700", 0, 4);
        addSignature("rar", "application/x-rar-compressed", "RAR архив v5", "526172211A070100", 0, 4);

        // 7-Zip
        addSignature("7z", "application/x-7z-compressed", "7-Zip архив", "377ABCAF271C", 0, 4);

        // GZIP
        addSignature("gz", "application/gzip", "GZIP архив", "1F8B08", 0, 4);

        // TAR
        addSignature("tar", "application/x-tar", "TAR архив", "7573746172", 0x101, 3);
    }

    private void addAudioVideoSignatures() {
        // MP3
        addSignature("mp3", "audio/mpeg", "MP3 аудио", "494433", 0, 3);

        // WAV
        addSignature("wav", "audio/wav", "WAV аудио", "52494646", 0, 3);

        // MP4
        addSignature("mp4", "video/mp4", "MP4 видео", "66747970", 4, 3);

        // AVI
        addSignature("avi", "video/x-msvideo", "AVI видео", "52494646", 0, 3);

        // MKV/WebM
        addSignature("mkv", "video/x-matroska", "Matroska видео", "1A45DFA3", 0, 3);
    }

    private void addExecutableSignatures() {
        // Windows
        addSignature("exe", "application/x-msdownload", "Исполняемый файл Windows", "4D5A", 0, 5);
        addSignature("dll", "application/x-msdownload", "Библиотека Windows", "4D5A", 0, 5);

        // Linux
        addSignature("elf", "application/x-executable", "Исполняемый файл Linux", "7F454C46", 0, 5);

        // macOS
        addSignature("macho", "application/x-mach-binary", "Исполняемый файл macOS", "FEEDFACE", 0, 5);

        // Java
        addSignature("jar", "application/java-archive", "Java архив", "504B0304", 0, 3);
        addSignature("class", "application/java-vm", "Java класс", "CAFEBABE", 0, 4);
    }

    private void addTextSignatures() {
        // Текстовые файлы с BOM
        addSignature("txt", "text/plain", "Текстовый файл (UTF-8 BOM)", "EFBBBF", 0, 2);
        addSignature("txt", "text/plain", "Текстовый файл (UTF-16)", "FEFF", 0, 2);

        // XML/HTML
        addSignature("xml", "application/xml", "XML документ", "3C3F786D6C", 0, 2);
        addSignature("html", "text/html", "HTML документ", "3C21444F4354595045", 0, 2);

        // JSON
        addSignature("json", "application/json", "JSON документ", "7B", 0, 1);
        addSignature("json", "application/json", "JSON массив", "5B", 0, 1);
    }

    private void addMiscellaneousSignatures() {
        // SQLite
        addSignature("sqlite", "application/x-sqlite3", "База данных SQLite",
                "53514C69746520666F726D61742033", 0, 4);

        // ISO
        addSignature("iso", "application/x-iso9660-image", "Образ диска ISO",
                "4344303031", 0x8001, 4);

        // Windows ярлык
        addSignature("lnk", "application/x-ms-shortcut", "Ярлык Windows",
                "4C00000001140200", 0, 4);
    }

    private void addSignature(String extension, String mimeType,
                              String description, String hexSignature,
                              int offset, int priority) {
        signatures.add(new FileSignature(extension, mimeType, description,
                hexSignature, offset, priority));
        extensionToMime.put(extension, mimeType);
    }

    public Optional<FileSignature> findSignature(byte[] fileBytes) {
        if (fileBytes == null || fileBytes.length < 4) {
            return Optional.empty();
        }

        String fileHex = HexUtils.bytesToHex(fileBytes, 64);

        // Группируем по приоритету
        Map<Integer, List<FileSignature>> matchesByPriority = new TreeMap<>(Collections.reverseOrder());

        for (FileSignature signature : signatures) {
            String sigHex = signature.getHexSignature();
            int offset = signature.getOffset();

            if (sigHex.isEmpty()) continue; // Пропускаем пустые сигнатуры

            if (fileBytes.length >= offset + sigHex.length() / 2) {
                if (fileHex.startsWith(sigHex, offset * 2)) {
                    int priority = signature.getPriority();
                    matchesByPriority
                            .computeIfAbsent(priority, k -> new ArrayList<>())
                            .add(signature);
                }
            }
        }

        // Ищем лучший матч
        for (Map.Entry<Integer, List<FileSignature>> entry : matchesByPriority.entrySet()) {
            List<FileSignature> matches = entry.getValue();

            // Если нашли ZIP - анализируем содержимое
            for (FileSignature sig : matches) {
                if (sig.getHexSignature().startsWith("504B03")) {
                    Optional<FileSignature> detailed = analyzeZipLikeFile(fileBytes, matches);
                    if (detailed.isPresent()) {
                        return detailed;
                    }
                }
            }

            // Возвращаем первый (самый надежный) сигнатуру с этого уровня приоритета
            return Optional.of(matches.get(0));
        }

        return Optional.empty();
    }

    private Optional<FileSignature> analyzeZipLikeFile(byte[] fileBytes,
                                                       List<FileSignature> zipSignatures) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(fileBytes);
            ZipInputStream zis = new ZipInputStream(bis);

            // Пытаемся прочитать первую запись
            ZipEntry entry = zis.getNextEntry();

            if (entry == null) {
                zis.close();
                // Пустой ZIP - возможно, это не ZIP, а другой файл с PK заголовком
                return detectOriginalFormatFromPK(fileBytes, zipSignatures);
            }

            // Анализируем содержимое архива
            Map<String, Integer> contentTypes = new HashMap<>();
            List<String> entryNames = new ArrayList<>();
            int totalEntries = 0;

            while (entry != null && totalEntries < 20) {
                String name = entry.getName().toLowerCase();
                entryNames.add(name);

                // Определяем тип по имени
                String type = detectFileTypeByName(name);
                contentTypes.put(type, contentTypes.getOrDefault(type, 0) + 1);

                totalEntries++;
                zis.closeEntry();
                entry = zis.getNextEntry();
            }
            zis.close();

            // Определяем тип архива по содержимому
            if (contentTypes.containsKey("office")) {
                return zipSignatures.stream()
                        .filter(s -> s.getExtension().equals("docx") ||
                                s.getExtension().equals("xlsx") ||
                                s.getExtension().equals("pptx"))
                        .findFirst()
                        .or(() -> Optional.of(new FileSignature("office_zip",
                                "application/zip", "Office документ в ZIP", "504B0304", 0, 3)));
            }

            if (contentTypes.containsKey("java")) {
                return zipSignatures.stream()
                        .filter(s -> s.getExtension().equals("jar"))
                        .findFirst();
            }

            // Обычный ZIP с файлами
            return zipSignatures.stream()
                    .filter(s -> s.getExtension().equals("zip"))
                    .findFirst()
                    .map(s -> {
                        String description = "ZIP архив";
                        if (!contentTypes.isEmpty()) {
                            String mainType = Collections.max(contentTypes.entrySet(),
                                    Map.Entry.comparingByValue()).getKey();
                            description += " (содержит: " + mainType + ")";
                        }
                        return new FileSignature(s.getExtension(), s.getMimeType(),
                                description, s.getHexSignature(), s.getOffset(), 3);
                    });

        } catch (Exception e) {
            // Если не смогли открыть как ZIP - определяем исходный формат
            return detectOriginalFormatFromPK(fileBytes, zipSignatures);
        }
    }

    private Optional<FileSignature> detectOriginalFormatFromPK(byte[] fileBytes,
                                                               List<FileSignature> zipSignatures) {
        // Анализируем байты для определения исходного формата
        String fileHex = HexUtils.bytesToHex(fileBytes, 32);

        // Проверяем другие возможные форматы, которые могут начинаться с похожих байт
        if (fileBytes.length > 10) {
            // PNG внутри "ZIP"
            if (fileHex.startsWith("89504E47")) {
                return Optional.of(new FileSignature("png", "image/png",
                        "PNG файл (ошибочно в архиве)", "89504E47", 0, 5));
            }

            // JPEG внутри "ZIP"
            if (fileHex.startsWith("FFD8FF")) {
                return Optional.of(new FileSignature("jpg", "image/jpeg",
                        "JPEG файл (ошибочно в архиве)", "FFD8FF", 0, 5));
            }

            // PDF внутри "ZIP"
            if (fileHex.startsWith("25504446")) {
                return Optional.of(new FileSignature("pdf", "application/pdf",
                        "PDF файл (ошибочно в архиве)", "25504446", 0, 5));
            }
        }

        // Если не определили - возвращаем обычный ZIP
        return zipSignatures.stream()
                .filter(s -> s.getExtension().equals("zip"))
                .findFirst();
    }

    private String detectFileTypeByName(String fileName) {
        if (fileName.endsWith(".class")) return "java";
        if (fileName.contains("word/") || fileName.contains("xl/") ||
                fileName.contains("ppt/")) return "office";
        if (fileName.endsWith(".java") || fileName.endsWith(".jar")) return "java";
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") ||
                fileName.endsWith(".png") || fileName.endsWith(".gif")) return "image";
        if (fileName.endsWith(".txt") || fileName.endsWith(".xml") ||
                fileName.endsWith(".html")) return "text";
        if (fileName.endsWith(".exe") || fileName.endsWith(".dll")) return "executable";
        return "other";
    }

    public String getStatistics() {
        long images = signatures.stream()
                .filter(s -> s.getMimeType().startsWith("image/"))
                .count();

        long documents = signatures.stream()
                .filter(s -> s.getMimeType().contains("document") ||
                        s.getMimeType().contains("pdf") ||
                        s.getMimeType().contains("msword") ||
                        s.getMimeType().contains("excel") ||
                        s.getMimeType().contains("powerpoint"))
                .count();

        long archives = signatures.stream()
                .filter(s -> s.isArchive())
                .count();

        long audioVideo = signatures.stream()
                .filter(s -> s.getMimeType().startsWith("audio/") ||
                        s.getMimeType().startsWith("video/"))
                .count();

        long executables = signatures.stream()
                .filter(s -> s.getExtension().equals("exe") ||
                        s.getExtension().equals("dll") ||
                        s.getExtension().equals("elf") ||
                        s.getExtension().equals("macho"))
                .count();

        return String.format(
                "Статистика базы сигнатур:\n" +
                        "  Изображения: %d\n" +
                        "  Документы: %d\n" +
                        "  Архивы: %d\n" +
                        "  Аудио/Видео: %d\n" +
                        "  Исполняемые: %d\n" +
                        "  Всего: %d",
                images, documents, archives, audioVideo, executables, signatures.size()
        );
    }
}