package com.fileanalyzer.core;

import com.fileanalyzer.model.AnalysisResult;
import com.fileanalyzer.model.FileSignature;
import com.fileanalyzer.util.HexUtils; // ← ДОБАВЬТЕ ЭТОТ ИМПОРТ!

import java.io.*;
import java.util.Arrays;
import java.util.Optional;
import java.util.zip.ZipInputStream;

public class FileAnalyzer {
    private final SignatureDatabase database;
    private static final int MAX_READ_SIZE = 8192;

    public FileAnalyzer() {
        this.database = new SignatureDatabase();
    }

    public AnalysisResult analyze(File file) throws IOException {
        AnalysisResult result = new AnalysisResult();

        try {
            // Базовая информация
            result.setFilePath(file.getAbsolutePath());
            result.setFileName(file.getName());
            result.setFileSize(file.length());

            // Текущее расширение
            String currentExt = getFileExtension(file.getName());
            result.setCurrentExtension(currentExt);

            // Читаем файл для анализа
            byte[] fileBytes = readFileBytes(file);

            if (fileBytes.length == 0) {
                result.setError("Файл пуст");
                return result;
            }

            // Определяем формат
            Optional<FileSignature> signature = database.findSignature(fileBytes);

            if (signature.isPresent()) {
                FileSignature sig = signature.get();

                result.setDetectedExtension(sig.getExtension());
                result.setMimeType(sig.getMimeType());
                result.setDescription(sig.getDescription());
                result.setSignatureMatch(true);

                // Уверенность в определении
                double confidence = calculateConfidence(sig, fileBytes);
                result.setConfidence(confidence);

                // Проверяем соответствие расширения
                boolean extensionMatch = !currentExt.isEmpty() &&
                        currentExt.equalsIgnoreCase(sig.getExtension());
                result.setExtensionMatch(extensionMatch);

                // Определяем исходный формат для архивов
                if (sig.isArchive() && sig.getDescription().contains("ошибочно")) {
                    String original = extractOriginalFormat(sig.getDescription());
                    result.setOriginalFormat(original);
                }

            } else {
                // Не удалось определить
                result.setDetectedExtension("unknown");
                result.setMimeType("application/octet-stream");
                result.setDescription("Неизвестный бинарный формат");
                result.setSignatureMatch(false);
                result.setConfidence(0.1);

                // Пробуем определить по содержимому
                if (HexUtils.isBinaryFile(fileBytes)) {
                    result.setDescription("Бинарный файл неизвестного формата");
                } else {
                    result.setDescription("Текстовый файл");
                    result.setDetectedExtension("txt");
                    result.setMimeType("text/plain");
                    result.setConfidence(0.3);
                }
            }

        } catch (Exception e) {
            result.setError("Ошибка анализа: " + e.getMessage());
            e.printStackTrace();
        }

        return result;
    }

    private byte[] readFileBytes(File file) throws IOException {
        int bytesToRead = (int) Math.min(file.length(), MAX_READ_SIZE);
        if (bytesToRead == 0) return new byte[0];

        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[bytesToRead];
            int read = fis.read(buffer);
            return read == buffer.length ? buffer : Arrays.copyOf(buffer, read);
        }
    }

    private String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex > 0 && dotIndex < fileName.length() - 1)
                ? fileName.substring(dotIndex + 1).toLowerCase()
                : "";
    }

    private double calculateConfidence(FileSignature sig, byte[] fileBytes) {
        double confidence = 0.5; // Базовая уверенность

        // Повышаем уверенность для надежных сигнатур
        if (sig.getPriority() >= 4) {
            confidence += 0.3;
        }

        // Проверяем длину сигнатуры (длинные = надежнее)
        if (sig.getHexSignature().length() >= 8) {
            confidence += 0.1;
        }

        // Для архивов проверяем возможность открытия
        if (sig.isArchive()) {
            try {
                new ZipInputStream(new ByteArrayInputStream(fileBytes))
                        .getNextEntry();
                confidence += 0.2; // Валидный архив
            } catch (Exception e) {
                confidence -= 0.1; // Невалидный архив
            }
        }

        return Math.min(1.0, confidence);
    }

    private String extractOriginalFormat(String description) {
        if (description.contains("PNG")) return "png";
        if (description.contains("JPEG") || description.contains("JPG")) return "jpg";
        if (description.contains("PDF")) return "pdf";
        if (description.contains("GIF")) return "gif";
        if (description.contains("BMP")) return "bmp";
        if (description.contains("TIFF") || description.contains("TIF")) return "tiff";
        return "unknown";
    }

    public boolean restoreExtension(File file) throws IOException {
        if (file == null || !file.exists()) {
            throw new IOException("Файл не существует");
        }

        AnalysisResult result = analyze(file);

        if (!result.isSignatureMatch() && result.getDetectedExtension().equals("unknown")) {
            System.err.println("Не удалось определить формат файла");
            return false;
        }

        String detectedExt = result.getDetectedExtension();
        String currentExt = result.getCurrentExtension();

        // Уже корректно
        if (currentExt.equalsIgnoreCase(detectedExt) ||
                detectedExt.equals("unknown") ||
                result.getConfidence() < 0.6) {
            System.out.println("Расширение корректно или низкая уверенность");
            return false;
        }

        // Меняем расширение
        String newName = changeFileExtension(file.getName(), detectedExt);
        File newFile = new File(file.getParent(), newName);

        if (newFile.exists()) {
            System.err.println("Файл с именем " + newFile.getName() + " уже существует");
            return false;
        }

        boolean success = file.renameTo(newFile);

        if (success) {
            System.out.println("✅ Файл успешно переименован:");
            System.out.println("   Было: " + file.getName());
            System.out.println("   Стало: " + newFile.getName());
            System.out.println("   Уверенность: " + (int)(result.getConfidence() * 100) + "%");
        } else {
            System.err.println("❌ Не удалось переименовать файл");
        }

        return success;
    }

    private String changeFileExtension(String fileName, String newExtension) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0) {
            return fileName.substring(0, dotIndex) + "." + newExtension;
        } else {
            return fileName + "." + newExtension;
        }
    }

    public File createBackup(File file) throws IOException {
        String backupName = file.getName() + ".backup";
        File backupFile = new File(file.getParent(), backupName);
        java.nio.file.Files.copy(
                file.toPath(),
                backupFile.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
        );
        System.out.println("Создана резервная копия: " + backupFile.getName());
        return backupFile;
    }

    public boolean restoreFromBackup(File file, File backup) {
        if (!backup.exists()) {
            System.err.println("Резервная копия не найдена");
            return false;
        }

        boolean success = backup.renameTo(file);
        System.out.println(success ? "Файл восстановлен" : "Не удалось восстановить");
        return success;
    }
}