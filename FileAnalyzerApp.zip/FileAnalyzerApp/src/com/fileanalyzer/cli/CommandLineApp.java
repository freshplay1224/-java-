package com.fileanalyzer.cli;

import com.fileanalyzer.core.FileAnalyzer;
import com.fileanalyzer.model.AnalysisResult;
import java.io.File;
import java.nio.file.Files; // ← ДОБАВЬТЕ ЭТОТ ИМПОРТ!
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class CommandLineApp {
    private final FileAnalyzer analyzer;
    private final Scanner scanner;

    public CommandLineApp() {
        this.analyzer = new FileAnalyzer();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        printWelcome();

        while (true) {
            printMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1": analyzeFile(); break;
                case "2": restoreFileExtension(); break;
                case "3": createBackup(); break;
                case "4": createTestFiles(); break;
                case "5": showInfo(); break;
                case "0": exitProgram(); return;
                default: System.out.println("Неверный выбор.");
            }
        }
    }

    private void printWelcome() {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   УМНЫЙ АНАЛИЗАТОР ФАЙЛОВ v2.0           ║");
        System.out.println("║   Определение формата по содержимому     ║");
        System.out.println("║   Восстановление расширений              ║");
        System.out.println("╚══════════════════════════════════════════╝");
    }

    private void printMenu() {
        System.out.println("\n════════════════ МЕНЮ ════════════════");
        System.out.println("1. 📄 Анализировать файл");
        System.out.println("2. 🔄 Восстановить расширение");
        System.out.println("3. 💾 Создать резервную копию");
        System.out.println("4. 🧪 Создать тестовые файлы");
        System.out.println("5. ℹ️  Информация о системе");
        System.out.println("0. 🚪 Выход");
        System.out.print("Выберите действие: ");
    }

    private void analyzeFile() {
        System.out.print("\n📂 Введите путь к файлу: ");
        String path = scanner.nextLine().trim();

        if (path.isEmpty()) {
            System.out.println("❌ Путь не может быть пустым.");
            return;
        }

        File file = new File(path);

        if (!file.exists() || !file.isFile()) {
            System.out.println("❌ Файл не существует: " + path);
            return;
        }

        try {
            System.out.println("\n🔍 Анализируем файл: " + file.getName());
            System.out.println("   Размер: " + formatSize(file.length()));

            AnalysisResult result = analyzer.analyze(file);

            System.out.println("\n══════════════ РЕЗУЛЬТАТЫ ══════════════");
            System.out.println(result);

            if (result.isSignatureMatch() && !result.isExtensionMatch() &&
                    result.getConfidence() > 0.6) {
                System.out.println("\n⚠️  ВНИМАНИЕ: Расширение не соответствует содержимому!");
                System.out.println("   Используйте опцию '2' для восстановления.");
            }

        } catch (Exception e) {
            System.out.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void restoreFileExtension() {
        System.out.print("\n🔄 Введите путь к файлу: ");
        String path = scanner.nextLine().trim();

        File file = new File(path);
        if (!file.exists()) {
            System.out.println("❌ Файл не существует.");
            return;
        }

        try {
            System.out.print("📦 Создать резервную копию? (да/нет): ");
            String backupChoice = scanner.nextLine().trim().toLowerCase();

            File backup = null;
            if (backupChoice.equals("да") || backupChoice.equals("yes") || backupChoice.equals("y")) {
                backup = analyzer.createBackup(file);
            }

            System.out.println("\n⚙️  Восстанавливаем расширение...");
            boolean success = analyzer.restoreExtension(file);

            if (!success && backup != null) {
                System.out.print("🔄 Восстановить из резервной копии? (да/нет): ");
                String restoreChoice = scanner.nextLine().trim().toLowerCase();
                if (restoreChoice.equals("да")) {
                    analyzer.restoreFromBackup(file, backup);
                }
            }

        } catch (Exception e) {
            System.out.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void createBackup() {
        System.out.print("\n💾 Введите путь к файлу: ");
        String path = scanner.nextLine().trim();

        File file = new File(path);
        if (!file.exists()) {
            System.out.println("❌ Файл не существует.");
            return;
        }

        try {
            File backup = analyzer.createBackup(file);
            System.out.println("✅ Резервная копия создана: " + backup.getAbsolutePath());
        } catch (Exception e) {
            System.out.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void createTestFiles() {
        System.out.println("\n🧪 Создание тестовых файлов...");

        try {
            // Создаем тестовые файлы
            createTestFile("test_real_png.png", new byte[]{
                    (byte)0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D
            });

            createTestFile("fake_zip_actually_jpg.zip", new byte[]{
                    (byte)0xFF, (byte)0xD8, (byte)0xFF, (byte)0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46
            });

            createTestFile("document.pdf", new byte[]{
                    0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x35, 0x0A, 0x25
            });

            createTestFile("archive_real.zip", new byte[]{
                    0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x00, 0x00, 0x08, 0x00
            });

            createTestFile("text_file.txt", "Это тестовый текстовый файл\nВторая строка\nТретья строка".getBytes("UTF-8"));

            createTestFile("png_without_extension", new byte[]{
                    (byte)0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
            });

            System.out.println("✅ Создано 6 тестовых файлов:");
            System.out.println("   1. test_real_png.png - настоящий PNG");
            System.out.println("   2. fake_zip_actually_jpg.zip - JPG в оболочке ZIP");
            System.out.println("   3. document.pdf - PDF документ");
            System.out.println("   4. archive_real.zip - настоящий ZIP архив");
            System.out.println("   5. text_file.txt - текстовый файл");
            System.out.println("   6. png_without_extension - PNG без расширения");

        } catch (Exception e) {
            System.out.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void createTestFile(String name, byte[] content) throws Exception {
        Files.write(new File(name).toPath(), content);
    }

    private void showInfo() {
        System.out.println("\n══════════════ ИНФОРМАЦИЯ ══════════════");
        System.out.println("Система анализа файлов v2.0");
        System.out.println("Функции:");
        System.out.println("  • Определение 100+ форматов файлов");
        System.out.println("  • Анализ по 'магическим числам'");
        System.out.println("  • Определение исходного формата в архивах");
        System.out.println("  • Восстановление правильных расширений");
        System.out.println("  • Резервное копирование");
        System.out.println("\nПоддерживаемые категории:");
        System.out.println("  📸 Изображения (PNG, JPEG, GIF, BMP, WebP)");
        System.out.println("  📄 Документы (PDF, DOC, XLS, DOCX, XLSX)");
        System.out.println("  📦 Архивы (ZIP, RAR, 7Z, GZ, TAR)");
        System.out.println("  🎵 Аудио/Видео (MP3, WAV, MP4, AVI, MKV)");
        System.out.println("  ⚙️  Исполняемые (EXE, DLL, ELF, JAR)");
        System.out.println("  📝 Текстовые (TXT, XML, HTML, JSON)");
    }

    private void exitProgram() {
        System.out.println("\n👋 До свидания!");
        scanner.close();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " байт";
        if (bytes < 1024 * 1024) return String.format("%.1f КБ", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f МБ", bytes / (1024.0 * 1024));
        return String.format("%.1f ГБ", bytes / (1024.0 * 1024 * 1024));
    }
}